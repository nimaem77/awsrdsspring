package com.example.aws.springbootpostgresaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootPostgresAwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootPostgresAwsApplication.class, args);
	}

}
